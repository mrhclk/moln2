﻿global using AutoMapper;
global using AutoMapper.QueryableExtensions;
global using MediatR;
global using Microsoft.EntityFrameworkCore;
